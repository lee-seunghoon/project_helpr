Types for Google Cloud Speech v1 API
====================================

.. automodule:: google.cloud.speech_v1.types
    :members:
    :undoc-members:
    :show-inheritance:
