Speech
------------------------

.. automodule:: google.cloud.speech_v1.services.speech
    :members:
    :inherited-members:
