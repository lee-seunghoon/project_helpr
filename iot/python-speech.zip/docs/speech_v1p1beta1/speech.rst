Speech
------------------------

.. automodule:: google.cloud.speech_v1p1beta1.services.speech
    :members:
    :inherited-members:
