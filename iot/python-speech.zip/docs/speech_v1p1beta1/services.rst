Services for Google Cloud Speech v1p1beta1 API
==============================================
.. toctree::
    :maxdepth: 2

    adaptation
    speech
