Types for Google Cloud Speech v1p1beta1 API
===========================================

.. automodule:: google.cloud.speech_v1p1beta1.types
    :members:
    :undoc-members:
    :show-inheritance:
