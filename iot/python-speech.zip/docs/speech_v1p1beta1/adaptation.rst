Adaptation
----------------------------

.. automodule:: google.cloud.speech_v1p1beta1.services.adaptation
    :members:
    :inherited-members:


.. automodule:: google.cloud.speech_v1p1beta1.services.adaptation.pagers
    :members:
    :inherited-members:
